import atomipy as ap

structure_atoms_0, structure_box_0 = ap.import_auto(f'UC_conf/Pyrophyllite_Lee_Guggenheim_1981_GII_0.071.pdb')
replicate_atoms_1, replicate_box_1, _ = ap.replicate_system(structure_atoms_0, structure_box_0, replicate=[6, 4, 3], keep_molid=True, keep_resname=True, renumber_index=True)
